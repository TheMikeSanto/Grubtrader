$(document).ready(function() {
	$(".mws-form input, .mws-form textarea").wrap($("<span></span>"));
});